<?php

declare(strict_types=1);

namespace Terminal42\NotificationCenterBundle\Token\Definition;

class FileTokenDefinition extends AbstractTokenDefinition
{
}
