<?php

declare(strict_types=1);

namespace Terminal42\NotificationCenterBundle\Token\Definition;

class HtmlTokenDefinition extends AbstractTokenDefinition
{
}
