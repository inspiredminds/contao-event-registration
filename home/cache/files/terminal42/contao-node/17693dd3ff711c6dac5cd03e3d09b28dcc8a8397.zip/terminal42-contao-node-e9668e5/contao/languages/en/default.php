<?php

/*
 * Content elements
 */
$GLOBALS['TL_LANG']['CTE']['nodes'] = ['Nodes', 'Include single or multiple content element nodes.'];

/*
 * Errors
 */
$GLOBALS['TL_LANG']['ERR']['invalidNodes'] = 'The folder nodes are not allowed: %s';
