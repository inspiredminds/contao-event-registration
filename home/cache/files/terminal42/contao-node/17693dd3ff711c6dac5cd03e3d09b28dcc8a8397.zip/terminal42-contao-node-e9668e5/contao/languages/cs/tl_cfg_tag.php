<?php


$GLOBALS['TL_LANG']['tl_cfg_tag']['sourceRef']['terminal42_node'] = 'Node';
