<?php

/*
 * Backend modules
 */
$GLOBALS['TL_LANG']['MOD']['nodes'] = ['Nodes', 'Create and manage content element nodes.'];

/*
 * Frontend modules
 */
$GLOBALS['TL_LANG']['FMD']['nodes'] = &$GLOBALS['TL_LANG']['CTE']['nodes'];
