<?php


$GLOBALS['TL_LANG']['tl_content']['nodes'] = ['Nodes', 'Wählen Sie ein oder mehrere Nodes aus.'];
$GLOBALS['TL_LANG']['tl_content']['nodesWrapper'] = ['Wrapper hinzufügen', 'Einen Wrapper um die ausgewählten Nodes ausgeben.'];
