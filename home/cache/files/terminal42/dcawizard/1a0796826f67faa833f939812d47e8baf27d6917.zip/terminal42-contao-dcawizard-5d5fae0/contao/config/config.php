<?php

use Terminal42\DcawizardBundle\Widget\DcaWizard;
use Terminal42\DcawizardBundle\Widget\DcaWizardMultilingual;

$GLOBALS['BE_FFL']['dcaWizard'] = DcaWizard::class;
$GLOBALS['BE_FFL']['dcaWizardMultilingual'] = DcaWizardMultilingual::class;
