<?php

namespace Fixtures\Bundles\RepositoryServiceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class RepositoryServiceBundle extends Bundle
{
}
