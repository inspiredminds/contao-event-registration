<?php

namespace Fixtures\Bundles\YamlBundle\Entity;

class Test
{
    /** @var mixed */
    private $id;
}
