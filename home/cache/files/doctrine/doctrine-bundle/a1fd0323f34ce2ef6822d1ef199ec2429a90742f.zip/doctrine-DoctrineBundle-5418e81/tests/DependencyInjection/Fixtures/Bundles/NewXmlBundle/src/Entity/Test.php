<?php

namespace Fixtures\Bundles\NewXmlBundle\Entity;

class Test
{
}
