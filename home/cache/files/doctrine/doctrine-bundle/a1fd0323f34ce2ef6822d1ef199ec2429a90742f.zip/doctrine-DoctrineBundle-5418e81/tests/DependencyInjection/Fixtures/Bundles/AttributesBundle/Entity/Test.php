<?php

namespace Fixtures\Bundles\AttributesBundle\Entity;

class Test
{
}
