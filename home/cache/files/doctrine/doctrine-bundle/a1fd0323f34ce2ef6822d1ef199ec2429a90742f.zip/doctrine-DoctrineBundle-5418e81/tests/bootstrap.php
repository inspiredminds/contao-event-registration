<?php

use Doctrine\Deprecations\Deprecation;

require_once 'vendor/autoload.php';

Deprecation::enableWithTriggerError();
