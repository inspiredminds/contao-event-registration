<?php

namespace Fixtures\Bundles\XmlBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class XmlBundle extends Bundle
{
}
