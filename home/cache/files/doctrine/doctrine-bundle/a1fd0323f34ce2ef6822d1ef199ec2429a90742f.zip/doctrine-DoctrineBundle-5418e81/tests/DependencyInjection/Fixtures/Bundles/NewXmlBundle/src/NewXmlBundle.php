<?php

namespace Fixtures\Bundles\NewXmlBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class NewXmlBundle extends Bundle
{
}
