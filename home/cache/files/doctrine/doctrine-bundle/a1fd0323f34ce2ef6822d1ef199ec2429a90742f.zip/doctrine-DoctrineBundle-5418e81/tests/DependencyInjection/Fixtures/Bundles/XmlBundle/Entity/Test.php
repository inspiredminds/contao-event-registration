<?php

namespace Fixtures\Bundles\XmlBundle\Entity;

class Test
{
}
