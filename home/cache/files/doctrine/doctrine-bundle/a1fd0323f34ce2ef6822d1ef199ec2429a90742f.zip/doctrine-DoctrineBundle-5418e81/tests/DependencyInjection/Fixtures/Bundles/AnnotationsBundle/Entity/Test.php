<?php

namespace Fixtures\Bundles\AnnotationsBundle\Entity;

class Test
{
}
