<?php

declare(strict_types=1);

/*
 * This file is part of Contao.
 *
 * (c) Leo Feyer
 *
 * @license LGPL-3.0-or-later
 */

namespace Contao\EasyCodingStandard\Set;

final class SetList
{
    public const CONTAO = __DIR__.'/../../config/contao.php';
}
