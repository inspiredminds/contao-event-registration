<?php

namespace Fixture;

class SomeClass {}
