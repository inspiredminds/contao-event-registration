<?php

declare (strict_types=1);
namespace Symplify\EasyCodingStandard\Exception\Configuration;

use Exception;
final class OutputFormatterNotFoundException extends Exception
{
}
