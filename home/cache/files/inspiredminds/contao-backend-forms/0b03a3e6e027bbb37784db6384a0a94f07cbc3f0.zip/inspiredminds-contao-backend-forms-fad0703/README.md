[![](https://img.shields.io/packagist/v/inspiredminds/contao-backend-forms.svg)](https://packagist.org/packages/inspiredminds/contao-backend-forms)
[![](https://img.shields.io/packagist/dt/inspiredminds/contao-backend-forms.svg)](https://packagist.org/packages/inspiredminds/contao-backend-forms)

Contao Backend Forms
=====================

Extension of `Codefog\HasteBundle\Form\Form` of `codefog/contao-haste` to quickly build a form for the back end.

This is still a work in progress.
