<?php

declare(strict_types=1);

namespace FeedIo;

class FeedIoException extends \RuntimeException
{
}
