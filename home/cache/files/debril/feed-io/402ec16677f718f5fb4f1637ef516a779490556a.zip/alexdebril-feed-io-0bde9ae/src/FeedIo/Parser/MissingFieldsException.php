<?php

declare(strict_types=1);

namespace FeedIo\Parser;

use FeedIo\FeedIoException;

class MissingFieldsException extends FeedIoException
{
}
