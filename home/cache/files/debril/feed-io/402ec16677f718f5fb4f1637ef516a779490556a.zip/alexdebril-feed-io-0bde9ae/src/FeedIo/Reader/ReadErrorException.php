<?php

declare(strict_types=1);

namespace FeedIo\Reader;

use FeedIo\FeedIoException;

class ReadErrorException extends FeedIoException
{
}
