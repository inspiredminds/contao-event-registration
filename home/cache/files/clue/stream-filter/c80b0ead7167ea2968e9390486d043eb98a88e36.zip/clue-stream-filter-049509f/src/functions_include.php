<?php

namespace Clue\StreamFilter;

// @codeCoverageIgnoreStart
if (!\function_exists(__NAMESPACE__ . '\\append')) {
    require __DIR__ . '/functions.php';
}
// @codeCoverageIgnoreEnd
