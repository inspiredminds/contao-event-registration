
/**
 * TODO: Write this comment
 * TODO
 */

// TODO: remove this.
alert('test');

// TODO remove this.
alert('test');

// todo - remove this.

// Extract info from the array.
// TODO: can this be done faster?

// Extract info from the array (todo: make it faster)
// To do this, use a function!
// notodo! NOTODO! NOtodo!
//TODO.
//étodo
//todoé
