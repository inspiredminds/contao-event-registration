Handorgel
=========

This is a customized package of the [Handorgel][1] plugin to be integrated
in [Contao Open Source CMS][2].


[1]: https://github.com/oncode/handorgel
[2]: https://contao.org
