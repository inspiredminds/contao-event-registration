ACE code editor
===============

This is a customized package of the [ACE code editor][1] to be integrated in
[Contao Open Source CMS][2].


[1]: http://ace.c9.io
[2]: https://contao.org
