jQuery
======

This is a customized [jQuery][1] distribution to be integrated in
[Contao Open Source CMS][2].


[1]: http://jquery.com
[2]: https://contao.org
