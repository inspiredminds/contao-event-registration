Date picker
===========

This is a customized MooTools [date picker][1] package to be integrated in
[Contao Open Source CMS][2].


[1]: https://github.com/arian/mootools-datepicker/
[2]: https://contao.org
