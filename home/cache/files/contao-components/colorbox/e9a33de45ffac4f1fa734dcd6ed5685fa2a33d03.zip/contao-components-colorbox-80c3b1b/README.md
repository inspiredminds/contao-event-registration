Colorbox
========

This is a customized package of the [Colorbox][1] jQuery plugin to be integrated
in [Contao Open Source CMS][2].


[1]: http://www.jacklmoore.com/colorbox/
[2]: https://contao.org
