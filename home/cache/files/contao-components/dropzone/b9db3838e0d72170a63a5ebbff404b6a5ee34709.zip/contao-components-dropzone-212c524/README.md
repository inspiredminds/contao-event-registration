DropZone
========

This is a customized package of the [DropZone][1] uploader to be integrated in
[Contao Open Source CMS][2].


[1]: http://www.dropzonejs.com
[2]: https://contao.org
