Chosen
======

This is a customized package of the [Chosen][1] MooTools plugin to be integrated
in [Contao Open Source CMS][2].


[1]: http://julesjanssen.github.io/chosen/
[2]: https://contao.org
