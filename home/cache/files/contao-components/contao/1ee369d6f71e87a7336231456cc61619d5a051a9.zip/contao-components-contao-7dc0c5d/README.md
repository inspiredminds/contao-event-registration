Contao assets
=============

These are the [Contao Open Source CMS][1] assets such as the CSS framework or
the MIME icons.


[1]: https://contao.org
