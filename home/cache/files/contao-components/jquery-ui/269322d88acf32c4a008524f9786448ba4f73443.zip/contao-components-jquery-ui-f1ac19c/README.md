jQuery UI
=========

This is a customized [jQuery UI][1] distribution to be integrated in
[Contao Open Source CMS][2].


[1]: http://jqueryui.com
[2]: https://contao.org
