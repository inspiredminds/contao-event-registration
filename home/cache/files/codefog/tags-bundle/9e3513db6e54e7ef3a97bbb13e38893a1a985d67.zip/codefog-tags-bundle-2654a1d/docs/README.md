# Tags Bundle – Documentation

1. [Installation](01-installation.md)
2. [Configuration](02-config.md)
3. [Usage](03-usage.md)
4. [Managers](04-managers.md)
5. [Backend interface](05-backend.md)
6. [Insert tags](06-insert-tags.md)
