<?php

declare(strict_types=1);

namespace Codefog\HasteBundle\Attribute;

#[\Attribute(\Attribute::TARGET_CLASS)]
class DoctrineOrmUndo
{
}
